cp -r /code/* /workspace && cd /workspace
python3.8 -u train.py > /code/rl_train.log
